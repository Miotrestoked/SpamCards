# SpamCards

This mod is simply a little project we made for our friends. Do not be surprised if stuff is broken or doesn't work, we are both very new to programming in c#. If you do decide to download it, have fun! :)
